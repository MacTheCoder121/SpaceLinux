qemu-system-x86_64 -cdrom kernel.iso
